import dotenv from 'dotenv'; 

export async function handler(req, res) {

    if(req.method !== 'GET') {
        res.status(405).json({ message: 'Only GET Methods Allowed!'}); 
        return; 
    }

    try {

        const response = await fetch('https://api.spoonacular.com/recipes/informationBulk', {
            method: 'GET', 
            headers: {
                'Content-Type': 'application/json', 

            }
        }); 

        if(!response.ok) {
            res.status(500).json({ message: 'Inernal Server Error!'});
            console.error(`Internal Server Error! ${response.status}`);
            return;  
        }
        
        const data = await response.json(); 
        console.log(data); 
        res.status(200).json({ messagre: 'Sucessfully Got Recipes!'}); 
    } catch(error) {
        res.status(500).json({ message: 'Internal Server Error!'}); 
        console.error('Internal Server Error', error); 
        return; 
    }
}